@echo off
rem ExSDR for Windows - builds ExSDR.exe (one file, with its icon) using PyInstaller
rem Needs Python 3.10 or newer from python.org.  Run this from the folder with exsdr.py.
cd /d "%~dp0"
echo Installing the Python packages ExSDR uses ...
py -m pip install --upgrade numpy sounddevice pyserial pillow pyinstaller
if errorlevel 1 goto failed
py exsdr.py --write-icon exsdr.ico
echo Building ExSDR.exe ...
py -m PyInstaller --noconfirm --onefile --windowed --name ExSDR --icon exsdr.ico exsdr.py
if errorlevel 1 goto failed
echo.
echo Done: dist\ExSDR.exe
echo Run "dist\ExSDR.exe --install-desktop" once for Start menu and desktop shortcuts.
pause
goto end
:failed
echo Something went wrong - see the messages above.
pause
:end
