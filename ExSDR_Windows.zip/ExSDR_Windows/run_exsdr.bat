@echo off
rem Run ExSDR from the Python source (installs the packages the first time)
cd /d "%~dp0"
py -c "import numpy, sounddevice, serial" 2>nul || py -m pip install numpy sounddevice pyserial pillow scipy
start "" pyw exsdr.py
