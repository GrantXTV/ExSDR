ExSDR for Windows
=================

ExSDR is one program for Linux and Windows. On Windows it uses PortAudio (the
sounddevice package) for sound and pyserial for the COM port.

1. Install Python 3.10 or newer from https://www.python.org/downloads/windows/
   and tick "Add python.exe to PATH" during setup.

2. Either
   a) double-click run_exsdr.bat - installs the packages the first time, then
      starts ExSDR, or
   b) double-click build_windows.bat - makes dist\ExSDR.exe, a single file you
      can copy to any Windows PC (no Python needed there).

3. Start menu and desktop shortcuts with the ExSDR icon:
      py exsdr.py --install-desktop        (or  ExSDR.exe --install-desktop)

4. In ExSDR: Settings > Sound devices. Use the WASAPI entries for the I/Q card
   (exact 192 kHz). In Windows Sound settings set the I/Q card to 2 channel,
   24 bit, 192000 Hz and turn "Audio enhancements" off for it.
   Settings > Radio > Serial port: the COM port of the ExSDR board
   (Device Manager > Ports shows which).

5. SDRs: put hackrf_transfer.exe / rtl_sdr.exe / airspyhf_rx.exe on the PATH;
   SDRplay and Pluto need PothosSDR or radioconda (SoapySDR).

More in ExSDR: Help (F1) > Windows.

  py exsdr.py --list-devices    shows the sound devices and COM ports ExSDR sees
  py exsdr.py --selftest        checks the DSP and modes
